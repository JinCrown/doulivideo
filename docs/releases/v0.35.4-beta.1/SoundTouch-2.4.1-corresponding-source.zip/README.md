# SoundTouch 2.4.1 对应组件材料

此压缩包仅提供第三方 SoundTouch 库的完整对应源码、许可证和独立构建方法，不包含抖哩听视频的业务源码。

SoundTouch 原作者：Olli Parviainen。许可：LGPL 2.1 或更新版本，见 third_party/soundtouch/COPYING.TXT。
上游完整归档：upstream-archive/soundtouch-2.4.1.tar.gz，SHA-256：35d404e6e8c2ebd12fb4000da6fadd75c99e37eed2126a04721828c11c0377ec。
随包的 third_party/soundtouch 文件保持上游算法源码不变。

使用 Android NDK 28.2.13676358，在解压目录运行：

ndk-build NDK_PROJECT_PATH=null APP_BUILD_SCRIPT=build/Android.mk NDK_APPLICATION_MK=build/Application.mk NDK_OUT=out/obj NDK_LIBS_OUT=out/lib NDK_DEBUG=0

可在 out/lib/<abi>/ 中得到动态库 libsoundtouch.so。NDK 路径需放进 PATH，或用 ndk-build.cmd / 完整 NDK 路径执行。

应用通过独立的 libbilitempo.so 动态链接 SoundTouch。替换兼容的 libsoundtouch.so 不需要应用业务源码或重新链接应用对象。
在 APK 副本中替换对应 lib/<abi>/libsoundtouch.so，使用 Android Build Tools 的 zipalign 对齐，再用你自己的测试签名签名。
修改签名后的 APK 不能覆盖原签名安装；请使用独立测试环境，保留本地数据。
允许为调试对此 LGPL 组件的修改而进行逆向工程。第三方许可证授予的权利不受应用业务源码不公开的限制。
