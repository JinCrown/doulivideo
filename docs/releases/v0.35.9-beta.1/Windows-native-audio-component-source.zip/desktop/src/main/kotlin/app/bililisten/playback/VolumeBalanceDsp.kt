package app.bililisten.playback

import kotlin.math.*

/** Linked-channel, streaming level adjustment. No frequency filtering or silence removal.
 * The caller provides a 10 ms block plus the following block's peak for lookahead protection.
 * All amplitudes are normalized to [-1, 1]; one gain preserves stereo phase and channel ratios.
 */
internal class VolumeBalanceDsp(private val sampleRate:Int,private val channels:Int) {
    private var energy=0.0
    private var measured=false
    private var levelGain=1.0
    private var outputGain=1.0
    private var wet=0.0
    private var previouslyEnabled=false
    private var disablingGain=1.0
    val gain:Double get()=outputGain

    init { require(sampleRate in 8000..192000 && channels in 1..8) }

    fun reset() {
        energy=0.0;measured=false;levelGain=1.0;outputGain=1.0
        wet=0.0;previouslyEnabled=false;disablingGain=1.0
    }

    fun process(input:FloatArray,frames:Int,nextPeak:Double,enabled:Boolean,output:FloatArray) {
        require(frames>0 && frames*channels<=input.size && frames*channels<=output.size)
        val count=frames*channels
        if(!enabled && wet==0.0) {
            input.copyInto(output,0,0,count)
            if(previouslyEnabled)reset()
            return
        }
        if(enabled && !previouslyEnabled) {energy=0.0;measured=false;levelGain=1.0}
        if(!enabled && previouslyEnabled)disablingGain=outputGain
        previouslyEnabled=enabled
        var sum=0.0;var peak=0.0
        for(i in 0 until count){val x=input[i].toDouble();sum+=x*x;peak=max(peak,abs(x))}
        val mean=sum/count
        val seconds=frames.toDouble()/sampleRate
        // Ignore pauses and very quiet background noise when estimating the programme level.
        // Holding the last gain also avoids boosting a breath or tail after every sentence.
        if(enabled && mean>=GATE*GATE) {
            energy=if(measured)energy+(mean-energy)*(1-exp(-seconds/.4)) else mean
            measured=true
            val wanted=(TARGET/sqrt(energy)).coerceIn(MIN_GAIN,MAX_GAIN)
            val tau=if(wanted<levelGain).2 else .65
            levelGain+=(wanted-levelGain)*(1-exp(-seconds/tau))
        }
        wet=(wet+if(enabled)seconds/.08 else -seconds/.08).coerceIn(0.0,1.0)
        val requested=1.0+((if(enabled)levelGain else disablingGain)-1.0)*wet
        val desired=if(enabled && mean<GATE*GATE)min(requested,outputGain) else requested
        // Previous block already saw this block's peak. Ramp toward the next block's safe gain
        // before its transient arrives; a slow release avoids audible pumping after a click.
        val ceiling=if(enabled && requested>1.000001)CEILING else 1.0
        val currentCap=if(peak>0)ceiling/peak else MAX_GAIN
        val aheadCap=if(nextPeak>0)ceiling/nextPeak else MAX_GAIN
        val protected=min(desired,min(currentCap,aheadCap))
        val start=min(outputGain,currentCap)
        val end=if(!enabled || protected<start)protected else start+(protected-start)*(1-exp(-seconds/.12))
        for(frame in 0 until frames) {
            val limited=start+(end-start)*(frame+1).toDouble()/frames
            for(channel in 0 until channels){val i=frame*channels+channel;output[i]=(input[i]*limited).toFloat()}
        }
        outputGain=end
        if(!enabled && wet==0.0)reset()
    }

    companion object {
        const val TARGET=.1 // Raise quiet programmes toward -20 dBFS; normal levels stay at unity.
        const val GATE=.0031622776601683794 // -50 dBFS; never chase digital silence.
        const val MAX_GAIN=3.9810717055349722 // +12 dB; lookahead limits peaks before any PCM clipping.
        const val MIN_GAIN=1.0 // Do not turn an ordinary programme down to a low fixed target.
        const val CEILING=.9440608762859234 // -0.5 dBFS sample-peak ceiling.
    }
}
