Mac audio component sources for DouliListen 0.14.22-beta.1.
Build on the target architecture using scripts/prepare-audio-macos.sh, after preparing VLC 3.0.24.
The VLC bridge is LGPL-2.1-or-later and dynamically linked; replace it with a compatible rebuild.
See UPSTREAM.txt for upstream VLC source URL and pinned checksum.
The component archive contains no application business source.
