/* DouliListen CoreAudio output observation. Does not change system settings. */
#include <CoreAudio/CoreAudio.h>
#include <CoreFoundation/CoreFoundation.h>
#include <stdlib.h>
#include <SystemConfiguration/SystemConfiguration.h>
#include <netinet/in.h>
#include <Network/Network.h>
#include <dispatch/dispatch.h>
#include <stdatomic.h>

typedef void (*device_callback)(const char *,const char *,int,int,int);
typedef void (*change_callback)(int);
static AudioObjectPropertyAddress property(AudioObjectPropertySelector selector,AudioObjectPropertyScope scope){return (AudioObjectPropertyAddress){selector,scope,kAudioObjectPropertyElementMain};}
static int number(AudioObjectID object,AudioObjectPropertySelector selector,UInt32 *value){AudioObjectPropertyAddress a=property(selector,kAudioObjectPropertyScopeGlobal);UInt32 size=sizeof(*value);return AudioObjectGetPropertyData(object,&a,0,NULL,&size,value);}
static int text(AudioObjectID object,AudioObjectPropertySelector selector,char *out,size_t capacity){
 AudioObjectPropertyAddress a=property(selector,kAudioObjectPropertyScopeGlobal);CFStringRef value=NULL;UInt32 size=sizeof(value);
 if(AudioObjectGetPropertyData(object,&a,0,NULL,&size,&value)||!value)return -1;
 int result=CFStringGetCString(value,out,capacity,kCFStringEncodingUTF8)?0:-1;CFRelease(value);return result;
}
__attribute__((visibility("default"))) int douli_audio_snapshot(unsigned pid,device_callback callback){
 (void)pid;AudioObjectPropertyAddress all=property(kAudioHardwarePropertyDevices,kAudioObjectPropertyScopeGlobal);UInt32 size=0,default_id=0;
 if(AudioObjectGetPropertyDataSize(kAudioObjectSystemObject,&all,0,NULL,&size))return -1;
 AudioDeviceID *devices=malloc(size);if(!devices)return -1;
 if(AudioObjectGetPropertyData(kAudioObjectSystemObject,&all,0,NULL,&size,devices)){free(devices);return -1;}
 number(kAudioObjectSystemObject,kAudioHardwarePropertyDefaultOutputDevice,&default_id);
 for(unsigned i=0;i<size/sizeof(*devices);i++){
  AudioObjectPropertyAddress streams=property(kAudioDevicePropertyStreams,kAudioDevicePropertyScopeOutput);UInt32 stream_size=0;
  if(AudioObjectGetPropertyDataSize(devices[i],&streams,0,NULL,&stream_size)||stream_size==0)continue;
  char uid[4096],name[4096];UInt32 type=0;
  if(text(devices[i],kAudioDevicePropertyDeviceUID,uid,sizeof(uid))||text(devices[i],kAudioObjectPropertyName,name,sizeof(name)))continue;
  number(devices[i],kAudioDevicePropertyTransportType,&type);
  int external=type==kAudioDeviceTransportTypeUSB||type==kAudioDeviceTransportTypeBluetooth||type==kAudioDeviceTransportTypeBluetoothLE||type==kAudioDeviceTransportTypeHDMI||type==kAudioDeviceTransportTypeDisplayPort||type==kAudioDeviceTransportTypeAirPlay||type==kAudioDeviceTransportTypeAVB||type==kAudioDeviceTransportTypeThunderbolt||type==kAudioDeviceTransportTypeFireWire;
  callback(uid,name,external,devices[i]==default_id,0);
 }
 free(devices);return 0;
}
typedef struct watcher{change_callback changed;}watcher;
static OSStatus changed(AudioObjectID object,UInt32 count,const AudioObjectPropertyAddress addresses[],void *context){
 (void)object;int critical=0;for(unsigned i=0;i<count;i++)if(addresses[i].mSelector==kAudioHardwarePropertyDefaultOutputDevice)critical=1;
 ((watcher*)context)->changed(critical);return noErr;
}
__attribute__((visibility("default"))) void *douli_audio_watch(change_callback callback){
 watcher *w=calloc(1,sizeof(*w));if(!w)return NULL;w->changed=callback;
 AudioObjectPropertyAddress a=property(kAudioHardwarePropertyDefaultOutputDevice,kAudioObjectPropertyScopeGlobal);
 AudioObjectPropertyAddress b=property(kAudioHardwarePropertyDevices,kAudioObjectPropertyScopeGlobal);
 if(AudioObjectAddPropertyListener(kAudioObjectSystemObject,&a,changed,w)){free(w);return NULL;}
 if(AudioObjectAddPropertyListener(kAudioObjectSystemObject,&b,changed,w)){AudioObjectRemovePropertyListener(kAudioObjectSystemObject,&a,changed,w);free(w);return NULL;}
 return w;
}
__attribute__((visibility("default"))) void douli_audio_unwatch(void *handle){
 watcher *w=handle;if(!w)return;
 AudioObjectPropertyAddress a=property(kAudioHardwarePropertyDefaultOutputDevice,kAudioObjectPropertyScopeGlobal),b=property(kAudioHardwarePropertyDevices,kAudioObjectPropertyScopeGlobal);
 AudioObjectRemovePropertyListener(kAudioObjectSystemObject,&a,changed,w);AudioObjectRemovePropertyListener(kAudioObjectSystemObject,&b,changed,w);free(w);
}

__attribute__((visibility("default"))) int douli_network_online(void){
 struct sockaddr_in address={0};address.sin_len=sizeof(address);address.sin_family=AF_INET;
 SCNetworkReachabilityRef reach=SCNetworkReachabilityCreateWithAddress(NULL,(const struct sockaddr*)&address);if(!reach)return -1;
 SCNetworkReachabilityFlags flags=0;int ok=SCNetworkReachabilityGetFlags(reach,&flags);CFRelease(reach);
 return !ok?-1:((flags&kSCNetworkReachabilityFlagsReachable)&&!(flags&kSCNetworkReachabilityFlagsConnectionRequired));
}
static atomic_int network_cost=-1;
static dispatch_once_t network_once;
static nw_path_monitor_t network_monitor;
__attribute__((visibility("default"))) int douli_network_cost(void){
 dispatch_once(&network_once, ^{
  network_monitor=nw_path_monitor_create();
  nw_path_monitor_set_queue(network_monitor,dispatch_get_global_queue(QOS_CLASS_UTILITY,0));
  nw_path_monitor_set_update_handler(network_monitor,^(nw_path_t path){atomic_store(&network_cost,nw_path_is_expensive(path)?1:0);});
  nw_path_monitor_start(network_monitor);
 });return atomic_load(&network_cost);
}

