/* SPDX-License-Identifier: LGPL-2.1-or-later
 * DouliListen VLC 3 audio bridge. The DSP runs in the existing Kotlin mobile
 * engine; this module only buffers a 10 ms lookahead and preserves PCM timing.
 */
#ifdef _WIN32
#include <winsock2.h>
static inline int poll(struct pollfd *fds,unsigned nfds,int timeout){return WSAPoll(fds,nfds,timeout);}
#else
#include <poll.h>
#endif
#include <vlc_common.h>
#include <vlc_plugin.h>
#include <vlc_aout.h>
#include <vlc_filter.h>
#include <math.h>
#include <string.h>

typedef void (*dsp_callback)(void *, int, unsigned, unsigned, float *, unsigned, double);
static dsp_callback bridge;
DLL_SYMBOL void douli_balance_set_callback(dsp_callback value) { bridge=value; }

struct filter_sys_t {
    unsigned rate,channels,block,pending_frames,building_frames;
    float *pending,*building;
    date_t clock;
};
static void notify(filter_t *f,int op,float *data,unsigned frames,double peak) {
    filter_sys_t *s=f->p_sys;
    if(bridge)bridge(s,op,s->rate,s->channels,data,frames,peak);
}
static double peak(const float *p,unsigned count) {
    double value=0;for(unsigned i=0;i<count;i++)value=fmax(value,fabs(p[i]));return value;
}
static unsigned emit(filter_t *f,float *out,double next) {
    filter_sys_t *s=f->p_sys;unsigned frames=s->pending_frames;
    if(frames){notify(f,0,s->pending,frames,next);memcpy(out,s->pending,frames*s->channels*sizeof(float));s->pending_frames=0;}
    return frames;
}
static block_t *finish(filter_t *f,block_t *out,unsigned frames) {
    filter_sys_t *s=f->p_sys;
    if(!frames){block_Release(out);return NULL;}
    out->i_buffer=frames*s->channels*sizeof(float);out->i_nb_samples=frames;
    out->i_dts=out->i_pts=date_Get(&s->clock);
    out->i_length=date_Increment(&s->clock,frames)-out->i_pts;
    return out;
}
static void flush(filter_t *f) {
    filter_sys_t *s=f->p_sys;s->pending_frames=0;s->building_frames=0;
    date_Set(&s->clock,VLC_TICK_INVALID);notify(f,1,NULL,0,0);
}
static block_t *process(filter_t *f,block_t *input) {
    if(!input)return NULL;
    filter_sys_t *s=f->p_sys;
    if(input->i_flags&BLOCK_FLAG_DISCONTINUITY)flush(f);
    if(date_Get(&s->clock)==VLC_TICK_INVALID)date_Set(&s->clock,input->i_pts);
    unsigned frames=input->i_nb_samples;
    if(frames>input->i_buffer/(s->channels*sizeof(float))){block_Release(input);return NULL;}
    block_t *out=block_Alloc(((size_t)frames+s->block)*s->channels*sizeof(float));
    if(!out){block_Release(input);return NULL;}
    float *source=(float*)input->p_buffer,*target=(float*)out->p_buffer;unsigned written=0;
    while(frames){
        unsigned n=s->block-s->building_frames;if(n>frames)n=frames;
        memcpy(s->building+s->building_frames*s->channels,source,n*s->channels*sizeof(float));
        frames-=n;source+=n*s->channels;s->building_frames+=n;
        if(s->building_frames==s->block){
            written+=emit(f,target+written*s->channels,peak(s->building,s->block*s->channels));
            float *swap=s->pending;s->pending=s->building;s->building=swap;
            s->pending_frames=s->building_frames;s->building_frames=0;
        }
    }
    block_Release(input);return finish(f,out,written);
}
static block_t *drain(filter_t *f) {
    filter_sys_t *s=f->p_sys;unsigned frames=s->pending_frames+s->building_frames;
    if(!frames)return NULL;
    block_t *out=block_Alloc(frames*s->channels*sizeof(float));if(!out)return NULL;
    float *target=(float*)out->p_buffer;
    unsigned written=emit(f,target,peak(s->building,s->building_frames*s->channels));
    if(s->building_frames){
        float *swap=s->pending;s->pending=s->building;s->building=swap;
        s->pending_frames=s->building_frames;s->building_frames=0;
        written+=emit(f,target+written*s->channels,0);
    }
    return finish(f,out,written);
}
static int open_filter(vlc_object_t *object) {
    if(!bridge)return VLC_EGENERIC;
    filter_t *f=(filter_t*)object;
    unsigned channels=aout_FormatNbChannels(&f->fmt_in.audio),rate=f->fmt_in.audio.i_rate;
    if(channels<1||channels>8||rate<8000||rate>192000)return VLC_EGENERIC;
    filter_sys_t *s=calloc(1,sizeof(*s));if(!s)return VLC_ENOMEM;
    s->channels=channels;s->rate=rate;s->block=rate/100;
    s->pending=calloc(s->block*channels,sizeof(float));s->building=calloc(s->block*channels,sizeof(float));
    if(!s->pending||!s->building){free(s->pending);free(s->building);free(s);return VLC_ENOMEM;}
    date_Init(&s->clock,rate,1);date_Set(&s->clock,VLC_TICK_INVALID);f->p_sys=s;
    f->fmt_in.audio.i_format=VLC_CODEC_FL32;aout_FormatPrepare(&f->fmt_in.audio);f->fmt_out.audio=f->fmt_in.audio;
    f->pf_audio_filter=process;f->pf_audio_drain=drain;f->pf_flush=flush;
    return VLC_SUCCESS;
}
static void close_filter(vlc_object_t *object) {
    filter_t *f=(filter_t*)object;filter_sys_t *s=f->p_sys;
    notify(f,2,NULL,0,0);free(s->pending);free(s->building);free(s);
}
vlc_module_begin()
    set_shortname("Douli volume balance")
    set_description("Douli mobile PCM volume balance bridge")
    set_capability("audio filter",0)
    add_shortcut("douli_balance")
    set_callbacks(open_filter,close_filter)
vlc_module_end()
