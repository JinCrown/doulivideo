#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
[[ "$(uname -m)" == arm64 ]] && arch=arm64 || arch=x64
runtime="$root/runtime/bundle/macos-$arch"
archive="$root/runtime/downloads/vlc-3.0.24.tar.xz"
source="$root/runtime/tools/vlc-source/vlc-3.0.24"
mkdir -p "$(dirname "$archive")" "$(dirname "$source")"
if [[ ! -f "$archive" ]]; then curl --fail --location --retry 3 'https://download.videolan.org/pub/videolan/vlc/3.0.24/vlc-3.0.24.tar.xz' -o "$archive"; fi
[[ "$(shasum -a 256 "$archive" | awk '{print $1}')" == e7cab503d1d7d5849b89d2cf0e1ee60d0ef6d012407791b644b9cfc0cc225fdf ]] || { echo 'VLC source checksum mismatch' >&2; exit 1; }
[[ -f "$source/include/vlc_filter.h" ]] || tar -xf "$archive" -C "$(dirname "$source")"
lib="$runtime/VLC.app/Contents/MacOS/lib"
plugins="$runtime/VLC.app/Contents/MacOS/plugins/audio_filter"
mkdir -p "$plugins" "$runtime/media-control"
xcrun clang -dynamiclib -O2 -std=c11 -D__PLUGIN__ '-DMODULE_STRING="douli_balance"' -I"$source/include" "$root/native/audio/douli_balance.c" -L"$lib" -lvlccore -o "$plugins/libdouli_balance_plugin.dylib"
install_name_tool -add_rpath '@loader_path/../../lib' "$plugins/libdouli_balance_plugin.dylib"
xcrun clang -dynamiclib -O2 -std=c11 -fblocks "$root/native/audio/audio_output_macos.c" -framework CoreAudio -framework CoreFoundation -framework SystemConfiguration -framework Network -o "$runtime/media-control/DouliAudio.dylib"
for binary in "$plugins/libdouli_balance_plugin.dylib" "$runtime/media-control/DouliAudio.dylib"; do codesign --force --sign - "$binary"; done
mkdir -p "$runtime/media-control/licenses/native-audio"
cp "$root/native/audio/COPYING.LIB" "$runtime/media-control/licenses/native-audio/"
