/* DouliListen Windows output observation; never changes the OS default device. */
#define COBJMACROS
#define INITGUID
#include <windows.h>
#include <mmdeviceapi.h>
#include <audiopolicy.h>
#include <netlistmgr.h>
#include <devicetopology.h>
#include <functiondiscoverykeys_devpkey.h>
#include <propvarutil.h>
#include <stdlib.h>
#include <string.h>

typedef void (*device_callback)(const char *,const char *,int,int,int);
typedef void (*change_callback)(int);
static char *utf8(const WCHAR *text){
 if(!text)return NULL;int count=WideCharToMultiByte(CP_UTF8,0,text,-1,NULL,0,NULL,NULL);
 char *value=malloc(count);if(value)WideCharToMultiByte(CP_UTF8,0,text,-1,value,count,NULL,NULL);return value;
}
static int own_session(IMMDevice *device,DWORD pid){
 IAudioSessionManager2 *manager=NULL;IAudioSessionEnumerator *list=NULL;int own=0,count=0;
 if(SUCCEEDED(IMMDevice_Activate(device,&IID_IAudioSessionManager2,CLSCTX_ALL,NULL,(void**)&manager))){
  if(SUCCEEDED(IAudioSessionManager2_GetSessionEnumerator(manager,&list))){
   IAudioSessionEnumerator_GetCount(list,&count);
   for(int i=0;i<count;i++){
    IAudioSessionControl *control=NULL;IAudioSessionControl2 *details=NULL;AudioSessionState state;DWORD owner=0;
    if(SUCCEEDED(IAudioSessionEnumerator_GetSession(list,i,&control))){
     if(SUCCEEDED(IAudioSessionControl_QueryInterface(control,&IID_IAudioSessionControl2,(void**)&details))){
      if(SUCCEEDED(IAudioSessionControl2_GetProcessId(details,&owner))&&owner==pid&&SUCCEEDED(IAudioSessionControl_GetState(control,&state))&&state==AudioSessionStateActive)own=1;
      IAudioSessionControl2_Release(details);
     }IAudioSessionControl_Release(control);
    }
   }IAudioSessionEnumerator_Release(list);
  }IAudioSessionManager2_Release(manager);
 }return own;
}
static int external_device(IMMDeviceEnumerator *enumerator,IMMDevice *device,IPropertyStore *store){
 PROPVARIANT value;PropVariantInit(&value);unsigned form=10;
 if(SUCCEEDED(IPropertyStore_GetValue(store,&PKEY_AudioEndpoint_FormFactor,&value))&&value.vt==VT_UI4)form=value.ulVal;
 PropVariantClear(&value);
 if(form==0||form==2||form==3||form==5||form==7||form==8||form==9)return 1;
 // Read the hardware device's enumerator property. Endpoint identifiers stay opaque.
 IDeviceTopology *topology=NULL;IConnector *connector=NULL;LPWSTR hardware_id=NULL;IMMDevice *hardware=NULL;IPropertyStore *properties=NULL;int external=0;
 if(SUCCEEDED(IMMDevice_Activate(device,&IID_IDeviceTopology,CLSCTX_ALL,NULL,(void**)&topology))){
  if(SUCCEEDED(IDeviceTopology_GetConnector(topology,0,&connector))){
   if(SUCCEEDED(IConnector_GetDeviceIdConnectedTo(connector,&hardware_id))){
    if(SUCCEEDED(IMMDeviceEnumerator_GetDevice(enumerator,hardware_id,&hardware))){
     if(SUCCEEDED(IMMDevice_OpenPropertyStore(hardware,STGM_READ,&properties))){
      PropVariantInit(&value);
      if(SUCCEEDED(IPropertyStore_GetValue(properties,&PKEY_Device_EnumeratorName,&value))&&value.vt==VT_LPWSTR){
       external=!_wcsicmp(value.pwszVal,L"USB")||!_wcsicmp(value.pwszVal,L"BTHENUM")||!_wcsicmp(value.pwszVal,L"BTHHFENUM")||!_wcsicmp(value.pwszVal,L"BTHLEDEVICE");
      }PropVariantClear(&value);IPropertyStore_Release(properties);
     }IMMDevice_Release(hardware);
    }CoTaskMemFree(hardware_id);
   }IConnector_Release(connector);
  }IDeviceTopology_Release(topology);
 }return external;
}
__declspec(dllexport) int douli_audio_snapshot(unsigned pid,device_callback callback){
 HRESULT init=CoInitializeEx(NULL,COINIT_MULTITHREADED);if(FAILED(init)&&init!=RPC_E_CHANGED_MODE)return -1;
 IMMDeviceEnumerator *enumerator=NULL;IMMDeviceCollection *list=NULL;IMMDevice *def=NULL;LPWSTR default_id=NULL;int result=-1;
 if(SUCCEEDED(CoCreateInstance(&CLSID_MMDeviceEnumerator,NULL,CLSCTX_ALL,&IID_IMMDeviceEnumerator,(void**)&enumerator))){
  if(SUCCEEDED(IMMDeviceEnumerator_GetDefaultAudioEndpoint(enumerator,eRender,eMultimedia,&def))){IMMDevice_GetId(def,&default_id);IMMDevice_Release(def);}
  if(SUCCEEDED(IMMDeviceEnumerator_EnumAudioEndpoints(enumerator,eRender,DEVICE_STATE_ACTIVE,&list))){
   UINT count=0;IMMDeviceCollection_GetCount(list,&count);result=0;
   for(UINT i=0;i<count;i++){
    IMMDevice *device=NULL;IPropertyStore *store=NULL;LPWSTR id=NULL;
    if(SUCCEEDED(IMMDeviceCollection_Item(list,i,&device))){
     if(SUCCEEDED(IMMDevice_GetId(device,&id))&&SUCCEEDED(IMMDevice_OpenPropertyStore(device,STGM_READ,&store))){
      PROPVARIANT name;PropVariantInit(&name);IPropertyStore_GetValue(store,&PKEY_Device_FriendlyName,&name);
      char *uid=utf8(id),*label=utf8(name.vt==VT_LPWSTR?name.pwszVal:L"音频输出");
      if(uid&&label)callback(uid,label,external_device(enumerator,device,store),default_id&&!_wcsicmp(id,default_id),own_session(device,pid));
      free(uid);free(label);PropVariantClear(&name);IPropertyStore_Release(store);
     }if(id)CoTaskMemFree(id);IMMDevice_Release(device);
    }
   }IMMDeviceCollection_Release(list);
  }if(default_id)CoTaskMemFree(default_id);IMMDeviceEnumerator_Release(enumerator);
 }if(SUCCEEDED(init))CoUninitialize();return result;
}

typedef struct watcher{IMMNotificationClient iface;LONG references,closing,inflight;HANDLE stop,thread,ready;change_callback changed;int active;} watcher;
static ULONG STDMETHODCALLTYPE add_ref(IMMNotificationClient *self){return InterlockedIncrement(&((watcher*)self)->references);}
static ULONG STDMETHODCALLTYPE release(IMMNotificationClient *self){ULONG refs=InterlockedDecrement(&((watcher*)self)->references);if(!refs)free(self);return refs;}
static void notify_change(IMMNotificationClient *self,int critical){watcher *w=(watcher*)self;InterlockedIncrement(&w->inflight);if(!InterlockedCompareExchange(&w->closing,0,0))w->changed(critical);InterlockedDecrement(&w->inflight);}
static HRESULT STDMETHODCALLTYPE query(IMMNotificationClient *self,REFIID id,void **out){
 if(!out)return E_POINTER;*out=NULL;
 if(IsEqualIID(id,&IID_IUnknown)||IsEqualIID(id,&IID_IMMNotificationClient)){*out=self;add_ref(self);return S_OK;}return E_NOINTERFACE;
}
static HRESULT STDMETHODCALLTYPE state_changed(IMMNotificationClient *self,LPCWSTR id,DWORD state){(void)id;notify_change(self,state==DEVICE_STATE_ACTIVE?0:1);return S_OK;}
static HRESULT STDMETHODCALLTYPE added(IMMNotificationClient *self,LPCWSTR id){(void)id;notify_change(self,0);return S_OK;}
static HRESULT STDMETHODCALLTYPE removed(IMMNotificationClient *self,LPCWSTR id){(void)id;notify_change(self,1);return S_OK;}
static HRESULT STDMETHODCALLTYPE default_changed(IMMNotificationClient *self,EDataFlow flow,ERole role,LPCWSTR id){(void)id;if(flow==eRender&&role==eMultimedia)notify_change(self,1);return S_OK;}
static HRESULT STDMETHODCALLTYPE property_changed(IMMNotificationClient *self,LPCWSTR id,const PROPERTYKEY key){(void)id;(void)key;notify_change(self,0);return S_OK;}
static IMMNotificationClientVtbl methods={query,add_ref,release,state_changed,added,removed,default_changed,property_changed};
static DWORD WINAPI watch_thread(void *arg){
 watcher *w=arg;HRESULT init=CoInitializeEx(NULL,COINIT_MULTITHREADED);IMMDeviceEnumerator *enumerator=NULL;
 if(SUCCEEDED(init)&&SUCCEEDED(CoCreateInstance(&CLSID_MMDeviceEnumerator,NULL,CLSCTX_ALL,&IID_IMMDeviceEnumerator,(void**)&enumerator))){
  w->active=SUCCEEDED(IMMDeviceEnumerator_RegisterEndpointNotificationCallback(enumerator,&w->iface));
 }SetEvent(w->ready);WaitForSingleObject(w->stop,INFINITE);
 if(enumerator){if(w->active)IMMDeviceEnumerator_UnregisterEndpointNotificationCallback(enumerator,&w->iface);IMMDeviceEnumerator_Release(enumerator);}
 if(SUCCEEDED(init))CoUninitialize();return 0;
}
__declspec(dllexport) void *douli_audio_watch(change_callback changed){
 watcher *w=calloc(1,sizeof(*w));if(!w)return NULL;w->iface.lpVtbl=&methods;w->references=1;w->changed=changed;
 w->stop=CreateEvent(NULL,TRUE,FALSE,NULL);w->ready=CreateEvent(NULL,TRUE,FALSE,NULL);w->thread=CreateThread(NULL,0,watch_thread,w,0,NULL);
 if(!w->thread){CloseHandle(w->stop);CloseHandle(w->ready);free(w);return NULL;}
 WaitForSingleObject(w->ready,INFINITE);return w;
}
__declspec(dllexport) void douli_audio_unwatch(void *handle){
 watcher *w=handle;if(!w)return;InterlockedExchange(&w->closing,1);SetEvent(w->stop);WaitForSingleObject(w->thread,INFINITE);
 while(InterlockedCompareExchange(&w->inflight,0,0))Sleep(1);
 CloseHandle(w->thread);CloseHandle(w->stop);CloseHandle(w->ready);release(&w->iface);
}

__declspec(dllexport) int douli_network_online(void){
 HRESULT init=CoInitializeEx(NULL,COINIT_MULTITHREADED);if(FAILED(init)&&init!=RPC_E_CHANGED_MODE)return -1;
 INetworkListManager *manager=NULL;int result=-1;VARIANT_BOOL online=VARIANT_FALSE;
 if(SUCCEEDED(CoCreateInstance(&CLSID_NetworkListManager,NULL,CLSCTX_ALL,&IID_INetworkListManager,(void**)&manager))){
  if(SUCCEEDED(INetworkListManager_IsConnectedToInternet(manager,&online)))result=online!=VARIANT_FALSE;
  INetworkListManager_Release(manager);
 }if(SUCCEEDED(init))CoUninitialize();return result;
}

__declspec(dllexport) int douli_network_cost(void){
 HRESULT init=CoInitializeEx(NULL,COINIT_MULTITHREADED);if(FAILED(init)&&init!=RPC_E_CHANGED_MODE)return -1;
 INetworkCostManager *manager=NULL;int result=-1;DWORD cost=0;
 if(SUCCEEDED(CoCreateInstance(&CLSID_NetworkListManager,NULL,CLSCTX_ALL,&IID_INetworkCostManager,(void**)&manager))){
  if(SUCCEEDED(INetworkCostManager_GetCost(manager,&cost,NULL))){
   if(cost&0x000f0006)result=1;else if(cost&1)result=0;
  }INetworkCostManager_Release(manager);
 }if(SUCCEEDED(init))CoUninitialize();return result;
}


