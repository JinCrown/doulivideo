param([string]$Toolchain)
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
foreach($relative in @('runtime/tools','runtime/downloads','runtime/bundle/windows-x64/vlc/plugins/audio_filter','runtime/bundle/windows-x64/media-control')){New-Item -ItemType Directory -Force -Path (Join-Path $root $relative) | Out-Null}
if(-not $Toolchain){$Toolchain=Join-Path $root 'runtime/tools/llvm-mingw-20261006-ucrt-x86_64'}
$toolArchive=Join-Path $root 'runtime/tools/llvm-mingw-20261006-ucrt-x86_64.zip'
$toolHash='317492c456aa27ee607a5919f1d2d38dcdc1112516a24d0bf4b00d078f52d17a'
if(-not(Test-Path -LiteralPath "$Toolchain/bin/clang.exe")){
 if(-not(Test-Path -LiteralPath $toolArchive)){Invoke-WebRequest -UseBasicParsing 'https://github.com/mstorsjo/llvm-mingw/releases/download/20261006/llvm-mingw-20261006-ucrt-x86_64.zip' -OutFile $toolArchive}
 if((Get-FileHash -LiteralPath $toolArchive -Algorithm SHA256).Hash -ine $toolHash){throw 'LLVM-MinGW checksum mismatch'}
 Expand-Archive -LiteralPath $toolArchive -DestinationPath (Join-Path $root 'runtime/tools') -Force
}
$sourceArchive=Join-Path $root 'runtime/downloads/vlc-3.0.24.tar.xz'
if(-not(Test-Path -LiteralPath $sourceArchive)){Invoke-WebRequest -UseBasicParsing 'https://download.videolan.org/pub/videolan/vlc/3.0.24/vlc-3.0.24.tar.xz' -OutFile $sourceArchive}
if((Get-FileHash -LiteralPath $sourceArchive -Algorithm SHA256).Hash -ine 'e7cab503d1d7d5849b89d2cf0e1ee60d0ef6d012407791b644b9cfc0cc225fdf'){throw 'VLC source checksum mismatch'}
$source=Join-Path $root 'runtime/tools/vlc-source'
if(-not(Test-Path -LiteralPath "$source/vlc-3.0.24/include/vlc_filter.h")){
 New-Item -ItemType Directory -Force -Path $source | Out-Null
 tar -xf $sourceArchive -C $source
 if($LASTEXITCODE -ne 0){throw 'VLC source extraction failed'}
}
$build=Join-Path $root 'build/audio-plugin'
New-Item -ItemType Directory -Force -Path $build | Out-Null
& "$Toolchain/bin/llvm-dlltool.exe" -m i386:x86-64 -d "$root/native/audio/libvlccore.def" -l "$build/libvlccore.dll.a"
if($LASTEXITCODE -ne 0){throw 'VLC import library build failed'}
& "$Toolchain/bin/clang.exe" -shared -O2 -std=c11 -D__PLUGIN__ '-DMODULE_STRING="douli_balance"' "-I$source/vlc-3.0.24/include" "$root/native/audio/douli_balance.c" "$build/libvlccore.dll.a" -o "$build/libdouli_balance_plugin.dll"
if($LASTEXITCODE -ne 0){throw 'PCM bridge build failed'}
& "$Toolchain/bin/clang.exe" -shared -O2 -std=c11 -D_WIN32_WINNT=0x0A00 "$root/native/audio/audio_output_windows.c" -lole32 -luuid -o "$build/DouliAudio.dll"
if($LASTEXITCODE -ne 0){throw 'CoreAudio observation build failed'}
$runtime=Join-Path $root 'runtime/bundle/windows-x64'
Copy-Item -LiteralPath "$build/libdouli_balance_plugin.dll" -Destination "$runtime/vlc/plugins/audio_filter/" -Force
Copy-Item -LiteralPath "$build/DouliAudio.dll" -Destination "$runtime/media-control/" -Force
$licenses=Join-Path $runtime 'media-control/licenses/native-audio'
New-Item -ItemType Directory -Force -Path $licenses | Out-Null
Copy-Item -LiteralPath "$root/native/audio/COPYING.LIB" -Destination $licenses -Force
Copy-Item -LiteralPath "$Toolchain/LICENSE.TXT" -Destination "$licenses/LLVM-MinGW-LICENSE.txt" -Force
Write-Output 'Built mobile PCM bridge and Windows actual-output observer'
